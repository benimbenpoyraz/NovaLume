# NovaLume Shaders — Minecraft 1.21 / Iris

NovaLume, Iris için hazırlanmış sinematik bir shader pack'tir. Sıcak gündüz renkleri, gece aydınlatması, dinamik gölgeler, hafif SSAO, ton eşleme ve isteğe bağlı bloom içerir.

## Özellikler
- **El şeffaflığını azalt:** `El Ayarları` içindeki `El Opaklığı` kaydırıcısı 0,50–1,00 aralığındadır. Iris'in `gbuffers_hand` aşaması elde tutulan eşyaları da işlediği için saydam dokulu eşyaları da etkileyebilir.
- **Cevher parlaması:** Yalnızca `shaders/block.properties` içinde listelenen cevher bloklarında, dokunun renkli piksellerine uygulanır. Gri taş pikselleri büyük ölçüde normal kalır; parlama komşu ekran piksellerine yayılmaz. Güç `0–3` aralığında ayarlanabilir.
- **Sınırsız Night Vision:** `Görsel Efektler` menüsünde açılıp kapatılır. Varsayılan olarak kapalıdır.
- **Ay parlaklığı ve boyutu:** `Ay Ayarları` içinde parlaklık `0,50–4,00`, boyut `0,80×–2,00×` aralığında ayarlanır. Varsayılan boyut `1,20×` değeridir.
- **Gece bulut parlaklığı:** `Bulut Ayarları` içindeki `Gece Bulut Parlaklığı` kaydırıcısı yalnızca gece ve alacakaranlıkta ek parlaklık uygular. Varsayılan `0,30` değeridir; `0,00` ile ek parlama kapatılır.
- **Biyoma göre bulut rengi:** Bulutların gece parlaması mevcut biyom kategorisine ve sıcaklık/yağış özelliklerine göre hafifçe altın, yeşil, turkuaz, mavi veya mor tona döner. `Biyoma Göre Bulut Rengi` kaydırıcısı renk etkisini `0–1` arasında ayarlar. Orijinal bulut dokusu ve alfa değeri korunur; renk etkisi gündüze doğru azalır. Renk, Iris tarafından sağlanan oyuncunun o an bulunduğu biyom bilgisine göre hesaplanır.

## Kurulum
1. Minecraft 1.21 için Iris ve Sodium kurulu olsun.
2. Bu ZIP dosyasını Minecraft'ın `shaderpacks` klasörüne kopyala. ZIP'i açma.
3. Oyunda **Ayarlar → Video Ayarları → Shader Packs** bölümünden NovaLume'u seç.
4. **Shader Pack Settings** bölümünden profili ve efekt ayarlarını düzenle.

## Profiller
- **LOW (Düşük):** 512 gölge haritası; gölgeler, SSAO, bloom ve sinematik renkler kapalı.
- **MEDIUM (Orta):** 2048 gölge haritası; gölgeler, yumuşak gölgeler, SSAO ve sinematik renkler açık.
- **HIGH (Yüksek):** 4096 gölge haritası; tüm görsel efektler açık.

## Uyum notu
Paket, Iris'in GLSL 330 compatibility shader hattını hedefler. ZIP bütünlüğü, dosya yapısı ve ayar referansları kontrol edilmiştir; ancak Minecraft içinde gerçek Iris derleme testi yapılamadığından tüm GPU/sürücü kombinasyonları için mutlak hatasızlık garantisi verilemez.
