#version 330 compatibility

#define SHADOWS // Dinamik güneş/ay gölgeleri
#define SOFT_SHADOWS // PCF ile daha yumuşak gölge kenarları
#define SSAO // Hafif ekran-uzayı ortam gölgelendirmesi
#define CINEMATIC_COLOR // Sıcak güneş, serin gölgeler ve canlı renkler
#define VIGNETTE // Çok hafif sinematik kenar gölgesi
#define ORE_GLOW // Renkli cevher piksellerini parlat
//#define NIGHT_VISION // Sınırsız gece görüşü (dünya bloklarını aydınlatır)
#define oreGlowStrength 1.50 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.25 2.50 3.00] Cevher parlaması gücü

const int shadowMapResolution = 2048; // [512 1024 1536 2048 3072 4096] Gölge haritası çözünürlüğü
/*
const int colortex0Format = RGBA16F;
const int colortex4Format = RGBA16F;
*/

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex4;
uniform sampler2D depthtex0;
uniform sampler2D shadowtex0;

uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjectionInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 shadowLightPosition;
uniform float viewWidth;
uniform float viewHeight;
uniform float rainStrength;
uniform int worldTime;

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

vec3 readOreColor(vec2 uv) {
    vec4 oreSample = texture(colortex4, clamp(uv, vec2(0.001), vec2(0.999)));
    return pow(max(oreSample.rgb, vec3(0.0)), vec3(2.2)) * oreSample.a;
}

vec3 projectAndDivide(mat4 projectionMatrix, vec3 position) {
    vec4 projected = projectionMatrix * vec4(position, 1.0);
    float safeW = abs(projected.w) < 0.000001 ? 0.000001 : projected.w;
    return projected.xyz / safeW;
}

float readShadow(vec3 shadowPos, vec3 normal, vec3 lightDir) {
#ifdef SHADOWS
    if (shadowPos.x <= 0.001 || shadowPos.y <= 0.001 || shadowPos.x >= 0.999 || shadowPos.y >= 0.999 || shadowPos.z <= 0.0 || shadowPos.z >= 1.0) {
        return 1.0;
    }

    float ndotl = max(dot(normal, lightDir), 0.0);
    float bias = 0.00065 + (1.0 - ndotl) * 0.00125;
#ifdef SOFT_SHADOWS
    float total = 0.0;
    vec2 texel = vec2(1.0 / float(shadowMapResolution));
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            vec2 sampleUV = shadowPos.xy + vec2(float(x), float(y)) * texel;
            float mapDepth = texture(shadowtex0, sampleUV).r;
            total += step(shadowPos.z - bias, mapDepth);
        }
    }
    return total / 9.0;
#else
    return step(shadowPos.z - bias, texture(shadowtex0, shadowPos.xy).r);
#endif
#else
    return 1.0;
#endif
}

float sampleAO(vec2 uv, float centerViewZ) {
#ifdef SSAO
    vec2 sampleUV = clamp(uv, vec2(0.001), vec2(0.999));
    float depth = texture(depthtex0, sampleUV).r;
    if (depth >= 0.999999) return 0.0;
    vec3 ndc = vec3(sampleUV * 2.0 - 1.0, depth * 2.0 - 1.0);
    vec3 samplePos = projectAndDivide(gbufferProjectionInverse, ndc);
    float delta = samplePos.z - centerViewZ;
    return smoothstep(0.10, 0.62, delta) * (1.0 - smoothstep(0.75, 2.20, delta));
#else
    return 0.0;
#endif
}

void main() {
    color = texture(colortex0, texcoord);
    // Perform lighting and post processing in approximately linear color space.
    color.rgb = pow(max(color.rgb, vec3(0.0)), vec3(2.2));
    vec3 sourceAlbedo = color.rgb;

    float depth = texture(depthtex0, texcoord).r;
    if (depth >= 0.999999) {
        return;
    }

    vec2 lightmap = clamp(texture(colortex1, texcoord).rg, 0.0, 1.0);
    vec3 encoded = texture(colortex2, texcoord).rgb;
    vec3 normal = normalize(encoded * 2.0 - 1.0);

    vec3 ndcPos = vec3(texcoord * 2.0 - 1.0, depth * 2.0 - 1.0);
    vec3 viewPos = projectAndDivide(gbufferProjectionInverse, ndcPos);
    vec3 feetPlayerPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;

    vec3 lightDirView = normalize(shadowLightPosition);
    vec3 lightDirWorld = normalize(mat3(gbufferModelViewInverse) * lightDirView);
    vec3 shadowViewPos = (shadowModelView * vec4(feetPlayerPos, 1.0)).xyz;
    vec4 shadowClipPos = shadowProjection * vec4(shadowViewPos, 1.0);
    shadowClipPos.z -= 0.0010;
    vec3 shadowNdc = shadowClipPos.xyz / max(abs(shadowClipPos.w), 0.000001);
    vec3 shadowScreenPos = shadowNdc * 0.5 + 0.5;
    float shadow = readShadow(shadowScreenPos, normal, lightDirWorld);

    float sunHeight = cos((float(worldTime) - 6000.0) * (6.28318530718 / 24000.0));
    float daylight = smoothstep(-0.22, 0.28, sunHeight);
    float weatherDim = 1.0 - 0.38 * clamp(rainStrength, 0.0, 1.0);

    vec3 torchColor = vec3(1.00, 0.48, 0.17);
    vec3 skyColor = mix(vec3(0.075, 0.105, 0.205), vec3(0.30, 0.43, 0.64), daylight);
    vec3 sunColor = mix(vec3(0.25, 0.31, 0.52), vec3(1.00, 0.82, 0.64), daylight);
    vec3 ambientColor = mix(vec3(0.105, 0.125, 0.175), vec3(0.205, 0.225, 0.245), daylight);

    float lambert = max(dot(normal, lightDirWorld), 0.0);
    float directStrength = mix(0.10, 0.92, daylight) * weatherDim;
    vec3 blockLight = torchColor * (lightmap.r * lightmap.r) * 2.25;
    vec3 skyLight = skyColor * lightmap.g * mix(0.50, 0.92, daylight);
    vec3 directLight = sunColor * lambert * shadow * directStrength;
    vec3 lighting = ambientColor + skyLight + blockLight + directLight;

#ifdef SSAO
    vec2 px = 2.25 / vec2(viewWidth, viewHeight);
    float occ = 0.0;
    occ += sampleAO(texcoord + vec2( px.x, 0.0), viewPos.z);
    occ += sampleAO(texcoord + vec2(-px.x, 0.0), viewPos.z);
    occ += sampleAO(texcoord + vec2(0.0,  px.y), viewPos.z);
    occ += sampleAO(texcoord + vec2(0.0, -px.y), viewPos.z);
    occ += sampleAO(texcoord + vec2( px.x,  px.y), viewPos.z);
    occ += sampleAO(texcoord + vec2(-px.x,  px.y), viewPos.z);
    occ += sampleAO(texcoord + vec2( px.x, -px.y), viewPos.z);
    occ += sampleAO(texcoord + vec2(-px.x, -px.y), viewPos.z);
    float ao = clamp(1.0 - occ * 0.023, 0.79, 1.0);
    lighting *= ao;
#endif

    color.rgb *= lighting;

#ifdef NIGHT_VISION
    // Keep the sampled block colors visible even in unlit caves.
    color.rgb = max(color.rgb, sourceAlbedo * 0.90);
#endif

#ifdef ORE_GLOW
    // Pixel-local emission only: no screen-space spill onto dirt, logs, or leaves.
    vec4 centerOre = texture(colortex4, texcoord);
    vec3 centerOreColor = pow(max(centerOre.rgb, vec3(0.0)), vec3(2.2)) * centerOre.a;
    color.rgb += centerOreColor * oreGlowStrength * 0.95;
#endif

#ifdef CINEMATIC_COLOR
    float luma = dot(color.rgb, vec3(0.2126, 0.7152, 0.0722));
    color.rgb = mix(vec3(luma), color.rgb, 1.13);
    color.rgb *= mix(vec3(1.035, 1.010, 0.985), vec3(1.015, 1.015, 1.025), 1.0 - daylight);
    color.rgb = mix(color.rgb, color.rgb * vec3(0.91, 0.96, 1.035), clamp(rainStrength, 0.0, 1.0) * 0.35);
#endif

#ifdef VIGNETTE
    vec2 centered = texcoord * 2.0 - 1.0;
    float vignette = 1.0 - smoothstep(0.48, 1.38, dot(centered, centered)) * 0.12;
    color.rgb *= vignette;
#endif
}
