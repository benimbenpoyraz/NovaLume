#version 330 compatibility

// This program targets only the vanilla sun/moon texture pass.
// The separate gbuffers_clouds program is intentionally untouched.
uniform vec3 moonPosition;

#define moonSize 1.20 // [0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00] Ay boyutu

out vec2 texcoord;
out vec4 glcolor;
flat out int moonFlag;

void main() {
    vec4 viewVertex = gl_ModelViewMatrix * gl_Vertex;
    vec3 moonDirection = normalize(moonPosition);
    vec3 vertexDirection = normalize(viewVertex.xyz);

    // Sun and moon use the same textured pass. Their view-space directions are opposite,
    // so this identifies the moon without affecting the sun.
    moonFlag = dot(vertexDirection, moonDirection) > 0.92 ? 1 : 0;

    if (moonFlag == 1) {
        // Enlarge the moon quad around its view-space center, without touching clouds.
        vec3 moonCenter = moonDirection * length(viewVertex.xyz);
        viewVertex.xyz = moonCenter + (viewVertex.xyz - moonCenter) * moonSize;
    }

    gl_Position = gl_ProjectionMatrix * viewVertex;
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor = gl_Color;
}
