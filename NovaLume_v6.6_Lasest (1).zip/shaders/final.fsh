#version 330 compatibility

uniform sampler2D colortex0;

in vec2 texcoord;

layout(location = 0) out vec4 color;

vec3 acesTonemap(vec3 x) {
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

void main() {
    vec4 scene = texture(colortex0, texcoord);
    vec3 mapped = acesTonemap(max(scene.rgb, vec3(0.0)));
    // Convert linear-light values for the display output.
    color = vec4(pow(mapped, vec3(1.0 / 2.2)), scene.a);
}
