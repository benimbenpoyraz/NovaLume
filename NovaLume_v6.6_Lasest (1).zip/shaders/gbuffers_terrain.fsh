#version 330 compatibility

#define ORE_GLOW // Renkli cevher piksellerini parlat

uniform sampler2D gtexture;
uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 worldNormal;
flat in float oreBlockFlag;

/* RENDERTARGETS: 0,1,2,4 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 lightmapData;
layout(location = 2) out vec4 encodedNormal;
layout(location = 3) out vec4 oreData;

float chroma(vec3 c) {
    return max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));
}

void main() {
    vec4 texel = texture(gtexture, texcoord);
    vec4 base = texel * glcolor;
    if (base.a < max(alphaTestRef, 0.1)) {
        discard;
    }

    color = base;
    lightmapData = vec4(clamp(lmcoord, 0.0, 1.0), 0.0, 1.0);
    encodedNormal = vec4(normalize(worldNormal) * 0.5 + 0.5, 1.0);

#ifdef ORE_GLOW
    // The block-ID gate means this mask runs only on ores listed in block.properties.
    // Then chroma selects colored texture pixels, leaving the gray stone matrix unlit.
    float maxChannel = max(texel.r, max(texel.g, texel.b));
    float pixelChroma = chroma(texel.rgb);
    float saturation = pixelChroma / max(maxChannel, 0.001);
    float colorMask = smoothstep(0.12, 0.28, pixelChroma)
                    * smoothstep(0.22, 0.40, saturation)
                    * smoothstep(0.18, 0.38, maxChannel);
    oreData = vec4(base.rgb, colorMask * oreBlockFlag);
#else
    oreData = vec4(0.0);
#endif
}
