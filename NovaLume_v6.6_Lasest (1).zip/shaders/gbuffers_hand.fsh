#version 330 compatibility

#define REDUCE_HAND_TRANSPARENCY // El ve eldeki eşyalardaki yarı saydamlığı azalt
#define handOpacity 0.90 // [0.50 0.60 0.70 0.80 0.90 0.95 1.00] El/eldeki eşya opaklığı

uniform sampler2D gtexture;
uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 worldNormal;

/* RENDERTARGETS: 0,1,2,4 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 lightmapData;
layout(location = 2) out vec4 encodedNormal;
layout(location = 3) out vec4 oreData;

void main() {
    vec4 base = texture(gtexture, texcoord) * glcolor;
    if (base.a < max(alphaTestRef, 0.1)) {
        discard;
    }

#ifdef REDUCE_HAND_TRANSPARENCY
    base.a = max(base.a, handOpacity);
#endif

    color = base;
    lightmapData = vec4(clamp(lmcoord, 0.0, 1.0), 0.0, 1.0);
    encodedNormal = vec4(normalize(worldNormal) * 0.5 + 0.5, 1.0);
    oreData = vec4(0.0);
}
