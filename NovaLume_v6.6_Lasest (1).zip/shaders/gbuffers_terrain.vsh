#version 330 compatibility

uniform mat4 gbufferModelViewInverse;

out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
out vec3 worldNormal;
in vec2 mc_Entity;
flat out float oreBlockFlag;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;

    vec3 viewNormal = gl_NormalMatrix * gl_Normal;
    worldNormal = normalize(mat3(gbufferModelViewInverse) * viewNormal);
    // block.properties assigns ID 100 only to vanilla ore blocks.
    // This prevents grass, leaves, wood, and other colorful blocks from glowing.
    oreBlockFlag = (abs(mc_Entity.x - 100.0) < 0.5) ? 1.0 : 0.0;
}
