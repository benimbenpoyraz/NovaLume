#version 330 compatibility

#define nightCloudBrightness 0.30 // [0.00 0.10 0.20 0.30 0.40 0.50 0.75 1.00 1.25 1.50] Gece bulut parlaklığı
#define biomeCloudColorStrength 0.65 // [0.00 0.15 0.30 0.45 0.60 0.75 0.90 1.00] Biyoma göre bulut renk etkisi

uniform sampler2D gtexture;
uniform float blindness;
uniform int isEyeInWater;
uniform int worldTime;
uniform int biome_category;
uniform float temperature;
uniform float rainfall;

in vec2 texcoord;
in vec4 glcolor;
in float fogDistance;

layout(location = 0) out vec4 color;

vec3 getBiomeCloudTint() {
    // Base tint by Iris biome category. Modest values preserve the texture's natural cloud detail.
    vec3 tint = vec3(0.82, 0.88, 1.12); // plains/default: cool moonlit blue

    if (biome_category == CAT_DESERT) {
        tint = vec3(1.22, 0.86, 0.56);       // sandy gold
    } else if (biome_category == CAT_MESA) {
        tint = vec3(1.20, 0.68, 0.48);       // terracotta
    } else if (biome_category == CAT_SAVANNA) {
        tint = vec3(1.16, 0.88, 0.58);       // warm amber
    } else if (biome_category == CAT_FOREST) {
        tint = vec3(0.62, 1.06, 0.78);       // leafy green
    } else if (biome_category == CAT_JUNGLE) {
        tint = vec3(0.48, 1.12, 0.78);       // tropical green
    } else if (biome_category == CAT_SWAMP) {
        tint = vec3(0.54, 0.92, 0.78);       // swamp teal
    } else if (biome_category == CAT_OCEAN) {
        tint = vec3(0.52, 0.78, 1.24);       // ocean blue
    } else if (biome_category == CAT_RIVER) {
        tint = vec3(0.58, 0.86, 1.20);       // river cyan
    } else if (biome_category == CAT_ICY) {
        tint = vec3(0.66, 0.88, 1.28);       // icy blue
    } else if (biome_category == CAT_TAIGA) {
        tint = vec3(0.62, 0.92, 1.16);       // alpine blue-green
    } else if (biome_category == CAT_EXTREME_HILLS) {
        tint = vec3(0.70, 0.90, 1.20);       // mountain blue
    } else if (biome_category == CAT_MUSHROOM) {
        tint = vec3(1.12, 0.70, 1.12);       // mushroom lilac
    } else if (biome_category == CAT_BEACH) {
        tint = vec3(1.10, 0.92, 0.72);       // pale sand
    } else if (biome_category == CAT_NETHER) {
        tint = vec3(1.18, 0.52, 0.48);       // ember red
    } else if (biome_category == CAT_THE_END) {
        tint = vec3(0.86, 0.68, 1.20);       // end violet
    }

    // Temperature and rainfall add smaller local variation inside each biome category.
    float warm = clamp((temperature - 0.15) / 1.25, 0.0, 1.0);
    float wet = clamp(rainfall, 0.0, 1.0);
    tint.r *= mix(0.94, 1.08, warm);
    tint.b *= mix(1.06, 0.94, warm);
    tint.g *= mix(0.96, 1.08, wet);

    return clamp(tint, vec3(0.25), vec3(1.35));
}

void main() {
    vec4 cloud = texture(gtexture, texcoord) * glcolor;

    // Fade the added brightness out through sunrise/daylight; at daytime the multiplier is 1.0.
    float sunHeight = cos((float(worldTime) - 6000.0) * (6.28318530718 / 24000.0));
    float daylight = smoothstep(-0.22, 0.28, sunHeight);
    float nightFactor = 1.0 - daylight;
    float brightness = 1.0 + nightCloudBrightness * nightFactor;
    cloud.rgb *= vec3(max(1.0 - blindness, 0.0) * brightness);

    // Biome coloring only affects the added night glow. It is gradually disabled by day,
    // and blends with the original cloud texture instead of replacing it with one flat color.
    float tintStrength = clamp(biomeCloudColorStrength, 0.0, 1.0) * nightFactor;
    cloud.rgb = mix(cloud.rgb, cloud.rgb * getBiomeCloudTint(), tintStrength);

    // Keep vanilla-style fog, water fog, cloud texture, and alpha intact.
    float fog = (isEyeInWater > 0)
        ? 1.0 - exp(-fogDistance * gl_Fog.density)
        : clamp((fogDistance - gl_Fog.start) * gl_Fog.scale, 0.0, 1.0);
    cloud.rgb = mix(cloud.rgb, gl_Fog.color.rgb, fog);

    color = cloud;
}
