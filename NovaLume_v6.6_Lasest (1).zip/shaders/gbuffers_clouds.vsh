#version 330 compatibility

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;

out vec4 glcolor;
out vec2 texcoord;
out float fogDistance;

void main() {
    // Match the standard textured gbuffers transform and preserve vanilla cloud geometry.
    vec3 pos = (gl_ModelViewMatrix * gl_Vertex).xyz;
    pos = (gbufferModelViewInverse * vec4(pos, 1.0)).xyz;
    gl_Position = gl_ProjectionMatrix * gbufferModelView * vec4(pos, 1.0);

    fogDistance = length(pos);
    glcolor = gl_Color;
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}
