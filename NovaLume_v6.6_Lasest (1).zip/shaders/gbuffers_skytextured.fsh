#version 330 compatibility

#define moonBrightness 2.50 // [0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.25 2.50 3.00 3.50 4.00] Ay parlaklığı

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 glcolor;
flat in int moonFlag;

layout(location = 0) out vec4 color;

void main() {
    vec4 texel = texture(gtexture, texcoord) * glcolor;

    // Brightness multiplier only applies to the moon. Sun and cloud passes are unchanged.
    if (moonFlag == 1) {
        texel.rgb *= moonBrightness;
    }

    color = texel;
}
