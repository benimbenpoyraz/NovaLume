#version 330 compatibility

#define BLOOM // Parlak alanlara hafif ışık saçılması

uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

vec3 brightPart(vec2 uv) {
    vec3 c = texture(colortex0, clamp(uv, vec2(0.001), vec2(0.999))).rgb;
    float luminance = dot(c, vec3(0.2126, 0.7152, 0.0722));
    return c * smoothstep(0.78, 1.65, luminance);
}

void main() {
    color = texture(colortex0, texcoord);
#ifdef BLOOM
    vec2 px = 1.0 / vec2(viewWidth, viewHeight);
    vec3 glow = vec3(0.0);
    glow += brightPart(texcoord + vec2( 2.0 * px.x, 0.0)) * 0.18;
    glow += brightPart(texcoord + vec2(-2.0 * px.x, 0.0)) * 0.18;
    glow += brightPart(texcoord + vec2(0.0,  2.0 * px.y)) * 0.18;
    glow += brightPart(texcoord + vec2(0.0, -2.0 * px.y)) * 0.18;
    glow += brightPart(texcoord + vec2( 1.4 * px.x,  1.4 * px.y)) * 0.07;
    glow += brightPart(texcoord + vec2(-1.4 * px.x,  1.4 * px.y)) * 0.07;
    glow += brightPart(texcoord + vec2( 1.4 * px.x, -1.4 * px.y)) * 0.07;
    glow += brightPart(texcoord + vec2(-1.4 * px.x, -1.4 * px.y)) * 0.07;
    color.rgb += glow * 0.065;
#endif
}
